
package prog6112practicaltestquestion1;
import java.util.Scanner;

public class Prog6112PracticalTestQuestion1 {

     public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Arrays to hold data for cities, cars, and motorbikes for the number of accidents
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        int[] carAccidents = new int[3];
        int[] bikeAccidents = new int[3];
        int[] totalAccidents = new int[3];

        // The input for accident data
        for (int i = 0; i < cities.length; i++) {
            System.out.println("Enter the number of car accidents for " + cities[i] + ": ");
            carAccidents[i] = scanner.nextInt();
            
            System.out.println("Enter the number of motorbike accidents for " + cities[i] + ": ");
            bikeAccidents[i] = scanner.nextInt();
            
            // Calculate total accidents for each city
            totalAccidents[i] = carAccidents[i] + bikeAccidents[i];
        }

        // Display road accident report 
        System.out.println("\nROAD ACCIDENT REPORT");
        System.out.printf("%-15s %-10s %-10s\n", "City", "Car", "Motorbike");
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-15s %-10d %-10d\n", cities[i], carAccidents[i], bikeAccidents[i]);
        }

        // Display total accidents for each city
        System.out.println("\nROAD ACCIDENT TOTALS FOR EACH CITY");
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-15s %-10d\n", cities[i], totalAccidents[i]);
        }

        // Find the city with the most vehicle accidents
        int maxAccidents = totalAccidents[0];
        String cityWithMostAccidents = cities[0];
        for (int i = 1; i < cities.length; i++) {
            if (totalAccidents[i] > maxAccidents) {
                maxAccidents = totalAccidents[i];
                cityWithMostAccidents = cities[i];
            }
        }

        System.out.println("\nCITY WITH THE MOST VEHICLE ACCIDENTS: " + cityWithMostAccidents);
        
        scanner.close();
    }
}
