/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112practicaltestquestion2;
public class Prog6112PracticalTestQuestion2 {

   
    public static void main(String[] args) {
        // TODO code application logic here
        String vehicleType = "Car";
        String city = "Cape Town";
        int accidentTotal = 155;
         // Create an instance of RoadAccidentReport
        RoadAccidentReport report = new RoadAccidentReport(vehicleType, city, accidentTotal);
        
        // Print the accident report
        report.printRoadAccidentReport();
    }
}
    




    
   
        
       

