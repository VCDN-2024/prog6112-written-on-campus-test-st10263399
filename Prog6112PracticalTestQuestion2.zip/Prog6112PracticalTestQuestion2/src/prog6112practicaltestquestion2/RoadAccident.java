/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog6112practicaltestquestion2;

/**
 *
 * @author lab_services_student
 */
public abstract class RoadAccident {
// Define the abstract class
abstract class RoadAccidents implements IRoadAccidents {
    protected String vehicleType;
    protected String city;
    protected int accidentTotal;
    
    // Constructor to initialize the vehicle type, city, and accident total
    public RoadAccidents(String vehicleType, String city, int accidentTotal) {
        this.vehicleType = vehicleType;
        this.city = city;
        this.accidentTotal = accidentTotal;
    }
    
    // Implement methods from the interface
    public String getAccidentVehicleType() {
        return vehicleType;
    }
    
    public String getCity() {
        return city;
    }
    
    public int getAccidentTotal() {
        return accidentTotal;
    }
    
    // Abstract method to print accident report (to be implemented by subclass)
    public abstract void printRoadAccidentReport();
}
    
}
